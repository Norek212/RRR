



export const shopItems = [
    {
        id: 'extra_work',
        name: 'Dodatkowa zmiana robocza',
        price: 5000,
        description: 'Pozwala na 1 dodatkowe użycie komendy `/work`.',
        type: 'consumable',
        maxQuantity: 5,
cooldown: 86400000,
        effect: {
            type: 'command_boost',
            command: 'work',
            uses: 1
        }
    },
    {
        id: 'bank_upgrade_1',
        name: 'Ulepszenie banku I',
        price: 15000,
        description: 'Zwiększa pojemność banku i pozwala na więcej depozytów.',
        type: 'upgrade',
        maxLevel: 5,
        effect: {
            type: 'bank_capacity',
            multiplier: 1.5
        }
    },
    {
        id: 'diamond_pickaxe',
        name: 'Diamentowy kilof',
        price: 50000,
        description: 'Zwiększa wydobycie z `/mine`',
        type: 'tool',
        durability: 100,
        effect: {
            type: 'mining_yield',
            multiplier: 2.0
        }
    },
    {
        id: 'premium_role',
        name: 'Rola Premium serwera',
        price: 15000,
        description: 'Specjalna rola dająca elegancki kolor i 10% bonus dzienny.',
        type: 'role',
roleId: null,
        effect: {
            type: 'daily_bonus',
            multiplier: 1.1
        }
    },
    {
        id: 'lucky_clover',
        name: 'Szczęśliwa koniczyna',
        price: 10000,
        description: 'Jednorazowo zwiększa szansę wygranej na `/gamble`.',
        type: 'consumable',
        maxQuantity: 10,
        effect: {
            type: 'gamble_boost',
            multiplier: 1.5,
            uses: 1
        }
    },
    {
        id: 'fishing_rod',
        name: '🎣 Wędka',
        price: 5000,
        description: 'Używana do komend wędkarskich',
        type: 'tool',
        durability: 100,
        effect: {
            type: 'fishing_yield',
            multiplier: 1.0
        }
    },
    {
        id: 'pickaxe',
        name: '⛏️ Kilof',
        price: 7500,
        description: 'Używany do komend górniczych',
        type: 'tool',
        durability: 100,
        effect: {
            type: 'mining_yield',
            multiplier: 1.2
        }
    },
    {
        id: 'laptop',
        name: '💻 Laptop',
        price: 15000,
        description: 'Zwiększa zarobki z pracy',
        type: 'tool',
        durability: 200,
        effect: {
            type: 'work_yield',
            multiplier: 1.5
        }
    },
    {
        id: 'lucky_charm',
        name: '🍀 Szczęśliwy talizman',
        price: 10000,
        description: 'Zwiększa szczęście przy hazardzie. Ma 3 użycia przed zużyciem.',
        type: 'consumable',
        maxQuantity: 10,
        effect: {
            type: 'gamble_boost',
            multiplier: 1.3,
            uses: 3
        }
    },
    {
        id: 'bank_note',
        name: '📜 Banknot',
        price: 25000,
        description: 'Zwiększa pojemność banku o 10,000. Można kupić wielokrotnie.',
        type: 'tool',
        durability: null,
        effect: {
            type: 'bank_capacity',
            increase: 10000
        }
    },
    {
        id: 'personal_safe',
        name: '🔒 Osobisty sejf',
        price: 30000,
        description: 'Chroni twoje pieniądze przed kradzieżą. Uniemożliwia okradanie.',
        type: 'tool',
        durability: null,
        effect: {
            type: 'robbery_protection',
            protection: true
        }
    }
];




export function getItemById(itemId) {
    return shopItems.find(item => item.id === itemId);
}




export function getItemsByType(type) {
    return shopItems.filter(item => item.type === type);
}




export function getItemPrice(itemId) {
    const item = getItemById(itemId);
    return item ? item.price : 0;
}




export function validatePurchase(itemId, userData) {
    const item = getItemById(itemId);
    if (!item) {
        return { valid: false, reason: 'Przedmiot nie znaleziony' };
    }

    const inventory = userData.inventory || {};
    const upgrades = userData.upgrades || {};

    if (item.type === 'consumable' && item.maxQuantity) {
        const currentQuantity = inventory[itemId] || 0;
        if (currentQuantity >= item.maxQuantity) {
            return { 
                valid: false, 
                reason: `Możesz mieć maksymalnie ${item.maxQuantity} sztuk ${item.name}` 
            };
        }
    }

    if (item.type === 'upgrade' && item.maxLevel) {
        if (upgrades[itemId]) {
            return { 
                valid: false, 
                reason: `Już kupiłeś ${item.name}` 
            };
        }
    }

    if (item.type === 'tool') {
        const currentQuantity = inventory[itemId] || 0;
        if (itemId !== 'bank_note' && currentQuantity > 0) {
            return { 
                valid: false, 
                reason: `Masz już ${item.name}` 
            };
        }
    }

    if (item.type === 'role' && item.roleId) {
        if (userData.roles?.includes(item.roleId)) {
            return { 
                valid: false, 
                reason: `Masz już rolę ${item.name}` 
            };
        }
    }

    return { valid: true };
}



