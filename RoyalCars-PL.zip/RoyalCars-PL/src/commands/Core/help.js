﻿import {
    SlashCommandBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} from "discord.js";
import { InteractionHelper } from '../../utils/interactionHelper.js';
import { createEmbed } from "../../utils/embeds.js";
import {
    createSelectMenu,
} from "../../utils/components.js";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CATEGORY_SELECT_ID = "help-category-select";
const ALL_COMMANDS_ID = "help-all-commands";
const BUG_REPORT_BUTTON_ID = "help-bug-report";
const HELP_MENU_TIMEOUT_MS = 5 * 60 * 1000;

const CATEGORY_ICONS = {
    Core: "ℹ️",
    Moderation: "🛡️",
    Economy: "💰",
    Fun: "🎮",
    Leveling: "📊",
    Utility: "🔧",
    Ticket: "🎫",
    Welcome: "👋",
    Giveaway: "🎉",
    Counter: "🔢",
    Tools: "🛠️",
    Search: "🔍",
    Reaction_Roles: "🎭",
    Community: "👥",
    Birthday: "🎂",
    Config: "⚙️",
};





export async function createInitialHelpMenu(client) {
    const commandsPath = path.join(__dirname, "../../commands");
    const categoryDirs = (
        await fs.readdir(commandsPath, { withFileTypes: true })
    )
        .filter((dirent) => dirent.isDirectory())
        .map((dirent) => dirent.name)
        .sort();

    const options = [
        {
            label: "📋 Wszystkie komendy",
            description: "Wyświetl wszystkie dostępne komendy ze stronicowaniem",
            value: ALL_COMMANDS_ID,
        },
        ...categoryDirs.map((category) => {
            const categoryName =
                category.charAt(0).toUpperCase() +
                category.slice(1).toLowerCase();
            const icon = CATEGORY_ICONS[categoryName] || "🔍";
            return {
                label: `${icon} ${categoryName}`,
                description: `Wyświetl komendy z kategorii ${categoryName}`,
                value: category,
            };
        }),
    ];

    const botName = client?.user?.username || "Bot";
    const embed = createEmbed({ 
        title: `🤖 ${botName} Help Center`,
        description: "Twój wszechstronny pomocnik Discord do moderacji, ekonomii, zabawy i zarządzania serwerem.",
        color: 'primary'
    });

    embed.addFields(
        {
            name: "🛡️ **Moderation**",
            value: "Narzędzia moderacji serwera, zarządzania użytkownikami i egzekwowania zasad",
            inline: true
        },
        {
            name: "💰 **Economy**",
            value: "System walut, sklepy i wirtualna ekonomia",
            inline: true
        },
        {
            name: "🎮 **Fun**",
            value: "Gry, rozrywka i interaktywne komendy",
            inline: true
        },
        {
            name: "📊 **Leveling**",
            value: "Poziomy użytkowników, system XP i śledzenie postępów",
            inline: true
        },
        {
            name: "🎫 **Tickets**",
            value: "System ticketów wsparcia do zarządzania serwerem",
            inline: true
        },
        {
            name: "🎉 **Giveaways**",
            value: "Zautomatyzowane zarządzanie i przeprowadzanie rozdań",
            inline: true
        },
        {
            name: "👋 **Welcome**",
            value: "Wiadomości powitalne dla nowych członków",
            inline: true
        },
        {
            name: "🎂 **Birthdays**",
            value: "Śledzenie i świętowanie urodzin",
            inline: true
        },
        {
            name: "👥 **Community**",
            value: "Narzędzia społeczności, podania i zaangażowanie członków",
            inline: true
        },
        {
            name: "⚙️ **Config**",
            value: "Komendy zarządzania konfiguracją serwera i bota",
            inline: true
        },
        {
            name: "🔢 **Counter**",
            value: "Konfiguracja kanału licznika na żywo i sterowanie licznikami",
            inline: true
        },
        {
            name: "🎙️ **Join to Create**",
            value: "Dynamiczne tworzenie i zarządzanie kanałami głosowymi",
            inline: true
        },
        {
            name: "🎭 **Reaction Roles**",
            value: "Role przypisywane samodzielnie przez system ról reakcji",
            inline: true
        },
        {
            name: "✅ **Verification**",
            value: "Procesy weryfikacji członków i kontrola dostępu",
            inline: true
        },
        {
            name: "🔧 **Utilities**",
            value: "Przydatne narzędzia i moduły serwera",
            inline: true
        }
    );

    embed.setFooter({ 
        text: "Stworzone z ❤️" 
    });
    embed.setTimestamp();

    const bugReportButton = new ButtonBuilder()
        .setCustomId(BUG_REPORT_BUTTON_ID)
        .setLabel("Zgłoś błąd")
        .setStyle(ButtonStyle.Danger);

    const supportButton = new ButtonBuilder()
        .setLabel("Serwer wsparcia")
        .setURL("https://discord.gg/QnWNz2dKCE")
        .setStyle(ButtonStyle.Link);

    const touchpointButton = new ButtonBuilder()
        .setLabel("Dowiedz się od Touchpoint")
        .setURL("https://www.youtube.com/@TouchDisc")
        .setStyle(ButtonStyle.Link);

    const selectRow = createSelectMenu(
        CATEGORY_SELECT_ID,
        "Wybierz, aby zobaczyć komendy",
        options,
    );

    const buttonRow = new ActionRowBuilder().addComponents([
        bugReportButton,
        supportButton,
        touchpointButton,
    ]);

    return {
        embeds: [embed],
        components: [buttonRow, selectRow],
    };
}

export default {
    data: new SlashCommandBuilder()
        .setName("help")
        .setDescription("Wyświetla menu pomocy ze wszystkimi dostępnymi komendami"),

    async execute(interaction, guildConfig, client) {
        
        const { MessageFlags } = await import('discord.js');
        await InteractionHelper.safeDefer(interaction);
        
        const { embeds, components } = await createInitialHelpMenu(client);

        await InteractionHelper.safeEditReply(interaction, {
            embeds,
            components,
        });

        setTimeout(async () => {
            try {
                const closedEmbed = createEmbed({
                    title: "Menu pomocy zamknięte",
                    description: "Menu pomocy zostało zamknięte. Użyj /help ponownie.",
                    color: "secondary",
                });

                await InteractionHelper.safeEditReply(interaction, {
                    embeds: [closedEmbed],
                    components: [],
                });
            } catch (error) {
                
            }
        }, HELP_MENU_TIMEOUT_MS);
    },
};


